import { useEffect, useMemo, useState } from 'react'
import { Bell, Calendar, Target, Zap, X, ChevronLeft, Star, TrendingUp, TrendingDown, Building2, Gauge } from 'lucide-react'
import { useAlerts } from '../hooks/useData'
import { useTickerHistory } from '../hooks/useBrvmChart'
import { StockChart } from '../components/StockChart'
import { supabase, type DbAlert } from '../lib/supabase'
import { SignalBadge } from '../components/SignalBadge'
import { RiskBadge } from '../components/RiskBadge'
import { RefreshButton } from '../components/RefreshButton'
import { markAlertRead } from '../hooks/useProfileStats'
import { useAlertValidations } from '../hooks/useAlertValidations'
import { formatRelativeTime, formatPrice } from '../lib/theme'
import { useAppStore } from '../lib/store'

interface ExtendedAlert extends DbAlert {
  ticker?: string | null
  sector?: string | null
  objectif_1?: number | null
  objectif_2?: number | null
  stop_loss?: number | null
}

function parseContent(raw: string | null) {
  if (!raw) return { message: '', priceMax: null as number | null, gainPotential: null as string | null }
  try {
    const p = JSON.parse(raw)
    if (typeof p === 'object' && p !== null && 'message' in p) {
      return { message: p.message || '', priceMax: p.price_max ?? null, gainPotential: p.gain_potential ?? null }
    }
  } catch {
    /* plain text content */
  }
  return { message: raw, priceMax: null, gainPotential: null }
}

function AlertCard({ alert, onOpen }: { alert: ExtendedAlert; onOpen: () => void }) {
  const content = parseContent(alert.content)
  const signal = alert.type === 'achat' ? 'ACHAT' : 'VENDRE'
  const accent = alert.type === 'achat' ? '#22C55E' : '#EF4444'

  return (
    <div
      onClick={() => {
        markAlertRead(alert.id)
        onOpen()
      }}
      className="rounded-2xl p-4 mb-3 cursor-pointer"
      style={{ backgroundColor: '#111118', border: '1px solid #2A2A3A', borderLeft: `3px solid ${accent}` }}
    >
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <SignalBadge signal={signal} size="sm" />
          <span className="text-white font-bold text-sm">{alert.stock_name}</span>
        </div>
        <span className="text-textMuted text-xs flex items-center gap-1">
          <Calendar size={12} /> {formatRelativeTime(new Date(alert.created_at))}
        </span>
      </div>

      {content.message && <p className="text-textSub text-sm leading-relaxed mb-3 line-clamp-2">{content.message}</p>}

      <div className="flex flex-wrap gap-4 mt-2">
        {alert.price_target != null && (
          <div className="flex items-center gap-1.5">
            <Target size={14} color="#F5C842" />
            <span className="text-white text-xs font-semibold">{formatPrice(alert.price_target)}</span>
          </div>
        )}
        {content.gainPotential && (
          <div className="flex items-center gap-1.5">
            <Zap size={14} color="#22C55E" />
            <span className="text-buy text-xs font-semibold">{content.gainPotential}</span>
          </div>
        )}
        {alert.horizon && (
          <span className="text-textMuted text-xs uppercase tracking-wide">
            Horizon {alert.horizon === 'long' ? 'long terme' : 'court terme'}
          </span>
        )}
      </div>
    </div>
  )
}

function DetailRow({ icon, label, value, valueColor }: { icon: React.ReactNode; label: string; value: React.ReactNode; valueColor?: string }) {
  return (
    <div className="flex items-center justify-between py-2.5" style={{ borderBottom: '1px solid #1E1E2A' }}>
      <span className="flex items-center gap-2 text-textSub text-xs">
        {icon} {label}
      </span>
      <span className="text-sm font-bold" style={{ color: valueColor ?? '#FFFFFF' }}>
        {value}
      </span>
    </div>
  )
}

function AlertDetail({ alert, onClose }: { alert: ExtendedAlert; onClose: () => void }) {
  const content = parseContent(alert.content)
  const { history, rsi } = useTickerHistory(alert.ticker ?? null)
  const { validatedAlerts, actionedIds, act } = useAlertValidations()
  const [currentPrice, setCurrentPrice] = useState<number | null>(null)
  const isBuy = alert.type === 'achat'
  const alreadyTracked = actionedIds.has(alert.id) || validatedAlerts.some((v) => v.id === alert.id)

  useEffect(() => {
    if (!alert.ticker) return
    supabase
      .from('brvm_cours')
      .select('cours')
      .eq('ticker', alert.ticker)
      .single()
      .then(({ data }) => setCurrentPrice(data?.cours ?? null))
  }, [alert.ticker])

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto" style={{ backgroundColor: '#0A0A0F' }}>
      <div className="flex items-center justify-between px-5 py-4" style={{ borderBottom: '1px solid #2A2A3A' }}>
        <button onClick={onClose} className="text-textSub flex items-center gap-1">
          <ChevronLeft size={20} /> Retour
        </button>
        <button onClick={onClose} className="text-textSub">
          <X size={20} />
        </button>
      </div>

      <div className="px-5 py-5">
        <div className="flex items-center justify-between mb-4 gap-3">
          <div>
            <h1 className="text-white font-extrabold text-xl">{alert.stock_name}</h1>
            {alert.sector && <p className="text-textSub text-xs mt-0.5">{alert.sector}</p>}
          </div>
          <span
            className="flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-extrabold flex-shrink-0"
            style={{
              backgroundColor: isBuy ? '#052E16' : '#200A0A',
              border: `1px solid ${isBuy ? '#166534' : '#7F1D1D'}`,
              color: isBuy ? '#22C55E' : '#EF4444',
            }}
          >
            {isBuy ? <TrendingUp size={14} /> : <TrendingDown size={14} />}
            {isBuy ? "OPPORTUNITÉ D'ACHAT" : 'OPPORTUNITÉ DE VENTE'}
          </span>
        </div>

        {/* Stats rapides */}
        <div className="grid grid-cols-2 gap-3 mb-5">
          <StatBox label="Type d'ordre" value={isBuy ? 'ACHAT' : 'VENTE'} color={isBuy ? '#22C55E' : '#EF4444'} />
          {alert.price_target != null && <StatBox label="Cours limite" value={formatPrice(alert.price_target)} />}
          {alert.horizon && <StatBox label="Horizon" value={alert.horizon === 'long' ? 'Long terme' : 'Court terme'} />}
          {content.gainPotential && <StatBox label="Potentiel de gain" value={content.gainPotential} color="#22C55E" />}
        </div>

        {/* Graphique */}
        {alert.ticker && (
          <div className="mb-5">
            <p className="text-textSub text-[11px] font-bold tracking-wide mb-2 uppercase">Graphique & historique</p>
            <StockChart history={history} rsi={rsi} />
          </div>
        )}

        {/* Détails */}
        <div className="rounded-2xl p-4 mb-5" style={{ backgroundColor: '#111118', border: '1px solid #2A2A3A' }}>
          <p className="text-white font-bold text-sm mb-1">Détails de l'alerte</p>
          <DetailRow icon={<Building2 size={13} />} label="Actif" value={alert.stock_name} />
          {alert.sector && <DetailRow icon={<Building2 size={13} />} label="Secteur" value={alert.sector} />}
          {currentPrice != null && <DetailRow icon={<Target size={13} />} label="Cours actuel" value={formatPrice(currentPrice)} />}
          {alert.price_target != null && <DetailRow icon={<Target size={13} />} label="Cours limite" value={formatPrice(alert.price_target)} valueColor="#F5C842" />}
          {alert.objectif_1 != null && <DetailRow icon={<TrendingUp size={13} />} label="Objectif 1" value={formatPrice(alert.objectif_1)} valueColor="#22C55E" />}
          {alert.objectif_2 != null && <DetailRow icon={<TrendingUp size={13} />} label="Objectif 2" value={formatPrice(alert.objectif_2)} valueColor="#22C55E" />}
          {alert.stop_loss != null && <DetailRow icon={<TrendingDown size={13} />} label="Stop loss" value={formatPrice(alert.stop_loss)} valueColor="#EF4444" />}
          {content.gainPotential && <DetailRow icon={<Zap size={13} />} label="Potentiel de gain moyen" value={content.gainPotential} valueColor="#22C55E" />}
          {alert.horizon && <DetailRow icon={<Calendar size={13} />} label="Horizon recommandé" value={alert.horizon === 'long' ? 'Long terme' : 'Court terme'} />}
          {alert.risk_level && (
            <div className="flex items-center justify-between py-2.5">
              <span className="flex items-center gap-2 text-textSub text-xs">
                <Gauge size={13} /> Niveau de risque
              </span>
              <RiskBadge level={alert.risk_level as 'Faible' | 'Modéré' | 'Élevé'} size="sm" />
            </div>
          )}
        </div>

        {content.message && (
          <div className="rounded-2xl p-4 mb-5" style={{ backgroundColor: '#111118', border: '1px solid #2A2A3A' }}>
            <p className="text-white font-bold text-sm mb-2">Analyse</p>
            <p className="text-textSub text-sm leading-relaxed whitespace-pre-wrap">{content.message}</p>
          </div>
        )}

        <button
          onClick={() => act(alert, 'validated')}
          disabled={alreadyTracked}
          className="w-full flex items-center justify-center gap-2 py-3.5 rounded-xl font-extrabold text-sm disabled:opacity-50"
          style={{ backgroundColor: '#F5C842', color: '#0A0A0F' }}
        >
          <Star size={16} /> {alreadyTracked ? 'Déjà dans votre portefeuille' : 'Ajouter au suivi'}
        </button>
        <p className="text-textMuted text-[11px] text-center mt-3">
          Alerte basée sur nos modèles d'analyse — données en temps réel
        </p>
      </div>
    </div>
  )
}

function StatBox({ label, value, color }: { label: string; value: string; color?: string }) {
  return (
    <div className="rounded-xl p-3" style={{ backgroundColor: '#111118', border: '1px solid #2A2A3A' }}>
      <p className="text-textMuted text-[10px] font-semibold tracking-wide uppercase mb-1">{label}</p>
      <p className="text-sm font-extrabold" style={{ color: color ?? '#FFFFFF' }}>{value}</p>
    </div>
  )
}

export default function Alertes() {
  const { alerts, loading, error, refetch } = useAlerts()
  const setUnread = useAppStore((s) => s.setUnreadAlertsCount)
  const [selected, setSelected] = useState<ExtendedAlert | null>(null)

  const sorted = useMemo(
    () => [...alerts].sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()),
    [alerts]
  )

  useEffect(() => {
    setUnread(alerts.length)
  }, [alerts, setUnread])

  return (
    <div className="min-h-screen pb-24" style={{ backgroundColor: '#0A0A0F' }}>
      <div className="px-5 pt-8 pb-4 flex items-end justify-between">
        <div>
          <p className="text-textSub text-[11px] font-semibold tracking-widest uppercase">Aujourd'hui</p>
          <h1 className="text-white font-extrabold text-[26px] tracking-tight mt-0.5">Alertes</h1>
        </div>
        <div className="flex items-center gap-2">
          <RefreshButton onClick={refetch} loading={loading} />
          <Bell size={22} color="#F5C842" />
        </div>
      </div>

      <div className="px-4">
        {loading && (
          <div className="flex flex-col gap-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-24 rounded-2xl animate-pulse" style={{ backgroundColor: '#111118' }} />
            ))}
          </div>
        )}

        {error && !loading && (
          <div className="text-center py-16">
            <p className="text-sell text-sm mb-3">{error}</p>
            <button onClick={refetch} className="text-primary text-sm font-semibold">
              Réessayer
            </button>
          </div>
        )}

        {!loading && !error && sorted.length === 0 && (
          <div className="text-center py-20">
            <Bell size={40} color="#4A4A5A" className="mx-auto mb-3" />
            <p className="text-textSub text-sm">Aucune alerte pour le moment</p>
          </div>
        )}

        {!loading && !error && sorted.map((a) => <AlertCard key={a.id} alert={a} onOpen={() => setSelected(a)} />)}
      </div>

      {selected && <AlertDetail alert={selected} onClose={() => setSelected(null)} />}
    </div>
  )
}
