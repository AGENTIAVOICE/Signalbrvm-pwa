import { useCallback, useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'

// Clé publique VAPID — sans risque à exposer côté client (c'est fait pour).
const VAPID_PUBLIC_KEY = 'BOe1I375DqzzBUQIvYOgs4eaBIC6UwuGdHVWZa336qmaYKwT9-0PhxMn-_bhZ7iJuk4Psqn_Ju3M4bDYrQ6rlXU'

function urlBase64ToUint8Array(base64String: string): Uint8Array {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4)
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/')
  const rawData = window.atob(base64)
  return Uint8Array.from([...rawData].map((c) => c.charCodeAt(0)))
}

export function usePushSubscription() {
  const [supported, setSupported] = useState(false)
  const [subscribed, setSubscribed] = useState(false)
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    const isSupported = 'serviceWorker' in navigator && 'PushManager' in window
    setSupported(isSupported)
    if (!isSupported) return
    navigator.serviceWorker.ready.then(async (reg) => {
      const sub = await reg.pushManager.getSubscription()
      setSubscribed(!!sub)
    })
  }, [])

  const subscribe = useCallback(async () => {
    if (!supported) return false
    setLoading(true)
    try {
      const permission = await Notification.requestPermission()
      if (permission !== 'granted') {
        setLoading(false)
        return false
      }
      const reg = await navigator.serviceWorker.ready
      let sub = await reg.pushManager.getSubscription()
      if (!sub) {
        sub = await reg.pushManager.subscribe({
          userVisibleOnly: true,
          applicationServerKey: urlBase64ToUint8Array(VAPID_PUBLIC_KEY) as BufferSource,
        })
      }
      const { data } = await supabase.auth.getSession()
      const userId = data.session?.user.id
      const json = sub.toJSON()
      if (userId && json.keys?.p256dh && json.keys?.auth && json.endpoint) {
        await supabase.from('push_subscriptions').upsert(
          {
            user_id: userId,
            endpoint: json.endpoint,
            p256dh: json.keys.p256dh,
            auth: json.keys.auth,
          },
          { onConflict: 'endpoint' }
        )
      }
      setSubscribed(true)
      setLoading(false)
      return true
    } catch (err) {
      console.error('Erreur abonnement push:', err)
      setLoading(false)
      return false
    }
  }, [supported])

  const unsubscribe = useCallback(async () => {
    if (!supported) return
    setLoading(true)
    try {
      const reg = await navigator.serviceWorker.ready
      const sub = await reg.pushManager.getSubscription()
      if (sub) {
        await supabase.from('push_subscriptions').delete().eq('endpoint', sub.endpoint)
        await sub.unsubscribe()
      }
      setSubscribed(false)
    } catch (err) {
      console.error('Erreur désabonnement push:', err)
    }
    setLoading(false)
  }, [supported])

  return { supported, subscribed, loading, subscribe, unsubscribe }
}
