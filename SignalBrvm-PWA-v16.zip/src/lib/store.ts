import { create } from 'zustand'

interface AppState {
  unreadAlertsCount: number
  unreadAnalysesCount: number
  setUnreadAlertsCount: (n: number) => void
  setUnreadAnalysesCount: (n: number) => void
}

export const useAppStore = create<AppState>((set) => ({
  unreadAlertsCount: 0,
  unreadAnalysesCount: 0,
  setUnreadAlertsCount: (n) => set({ unreadAlertsCount: n }),
  setUnreadAnalysesCount: (n) => set({ unreadAnalysesCount: n }),
}))
