import type { HistoryPoint } from '../hooks/useBrvmChart'
import { formatGMTDate } from '../lib/theme'

export function StockChart({
  history,
  rsi,
  height = 180,
}: {
  history: HistoryPoint[]
  rsi: (number | null)[]
  height?: number
}) {
  if (history.length < 2) {
    return (
      <div
        className="flex items-center justify-center rounded-xl text-textMuted text-xs text-center px-4"
        style={{ height, backgroundColor: '#0D0D14', border: '1px solid #2A2A3A' }}
      >
        Historique encore trop court pour tracer un graphique (revient dans quelques jours).
      </div>
    )
  }

  const W = 600
  const H = height
  const closes = history.map((h) => Number(h.cours))
  const min = Math.min(...closes)
  const max = Math.max(...closes)
  const pad = (max - min) * 0.1 || 1
  const yMin = min - pad
  const yMax = max + pad

  const x = (i: number) => (i / (history.length - 1)) * W
  const y = (v: number) => H - ((v - yMin) / (yMax - yMin)) * H

  const linePath = closes.map((c, i) => `${i === 0 ? 'M' : 'L'} ${x(i)} ${y(c)}`).join(' ')
  const areaPath = `${linePath} L ${W} ${H} L 0 ${H} Z`

  const lastRsi = [...rsi].reverse().find((v) => v != null) ?? null
  const rsiValid = rsi.some((v) => v != null)

  return (
    <div className="flex flex-col gap-1">
      <div className="rounded-xl overflow-hidden" style={{ backgroundColor: '#0D0D14', border: '1px solid #2A2A3A' }}>
        <svg viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" style={{ width: '100%', height }}>
          <defs>
            <linearGradient id="stockFill" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0" stopColor="#F5C842" stopOpacity="0.22" />
              <stop offset="1" stopColor="#F5C842" stopOpacity="0" />
            </linearGradient>
          </defs>
          <path d={areaPath} fill="url(#stockFill)" />
          <path d={linePath} fill="none" stroke="#F5C842" strokeWidth="2" />
        </svg>
      </div>

      <div className="flex items-center justify-between px-1">
        <span className="text-textMuted text-[10px]">{formatGMTDate(new Date(history[0].day))}</span>
        {rsiValid && (
          <span className="text-[10px] font-bold" style={{ color: '#8B5CF6' }}>
            RSI(14) {lastRsi?.toFixed(1)}
          </span>
        )}
        <span className="text-textMuted text-[10px]">{formatGMTDate(new Date(history[history.length - 1].day))}</span>
      </div>

      {rsiValid && (
        <div className="rounded-xl overflow-hidden mt-1" style={{ backgroundColor: '#0D0D14', border: '1px solid #2A2A3A', height: 60 }}>
          <svg viewBox={`0 0 ${W} 60`} preserveAspectRatio="none" style={{ width: '100%', height: 60 }}>
            <line x1="0" y1={60 - 0.7 * 60} x2={W} y2={60 - 0.7 * 60} stroke="#3A3A4A" strokeDasharray="4 3" strokeWidth="1" />
            <line x1="0" y1={60 - 0.3 * 60} x2={W} y2={60 - 0.3 * 60} stroke="#3A3A4A" strokeDasharray="4 3" strokeWidth="1" />
            <path
              d={rsi
                .map((v, i) => (v == null ? null : `${v == null ? 'M' : 'L'} ${x(i)} ${60 - (v / 100) * 60}`))
                .filter(Boolean)
                .join(' ')
                .replace(/^L/, 'M')}
              fill="none"
              stroke="#8B5CF6"
              strokeWidth="1.5"
            />
          </svg>
        </div>
      )}
    </div>
  )
}
