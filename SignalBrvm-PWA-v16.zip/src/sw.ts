/// <reference lib="webworker" />
// Service worker personnalisé : garde tout le comportement PWA existant
// (précaching via injectManifest, mise en cache réseau) ET ajoute la gestion
// des notifications push web — ce que le service worker auto-généré ne
// permet pas de faire.

import { precacheAndRoute } from 'workbox-precaching'
import { NetworkFirst } from 'workbox-strategies'
import { registerRoute } from 'workbox-routing'

declare let self: ServiceWorkerGlobalScope

precacheAndRoute(self.__WB_MANIFEST)

registerRoute(
  ({ url }) => /\.supabase\.co\//.test(url.href),
  new NetworkFirst({ cacheName: 'supabase-cache', networkTimeoutSeconds: 8 })
)
registerRoute(
  ({ url }) => /pebble-coaster\.vibecode\.run\//.test(url.href),
  new NetworkFirst({ cacheName: 'backend-cache', networkTimeoutSeconds: 8 })
)

self.addEventListener('install', () => {
  self.skipWaiting()
})
self.addEventListener('activate', () => {
  self.clients.claim()
})

// ── Notifications push ───────────────────────────────────────────────────────
self.addEventListener('push', (event) => {
  let data: { title?: string; body?: string; url?: string } = {}
  try {
    data = event.data?.json() ?? {}
  } catch {
    data = { title: 'SignalBrvm', body: event.data?.text() ?? 'Nouveau contenu disponible.' }
  }

  const title = data.title ?? 'SignalBrvm'
  const options: NotificationOptions = {
    body: data.body ?? 'Nouveau contenu disponible.',
    icon: '/icon-192.png',
    badge: '/icon-192.png',
    data: { url: data.url ?? '/alertes' },
  }

  event.waitUntil(self.registration.showNotification(title, options))
})

self.addEventListener('notificationclick', (event) => {
  event.notification.close()
  const targetUrl = (event.notification.data?.url as string) ?? '/alertes'

  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientsArr) => {
      const existing = clientsArr.find((c) => 'focus' in c)
      if (existing) {
        existing.navigate(targetUrl)
        return existing.focus()
      }
      return self.clients.openWindow(targetUrl)
    })
  )
})
