import { useEffect, useRef, useState } from 'react'
import { Bell, Plus, Trash2, Edit3, EyeOff, Eye } from 'lucide-react'
import { adminApi } from '../../lib/adminApi'
import type { DbAlert } from '../../lib/supabase'
import { formatRelativeTime } from '../../lib/theme'
import { useBrvmTickers, useTickerHistory } from '../../hooks/useBrvmChart'
import { StockChart } from '../../components/StockChart'
import { ScreenHeader, EmptyState, ModalSheet, FieldLabel, TextInput, TextArea, Toggle, PillGroup } from '../../components/admin/AdminUI'

interface FormState {
  id?: string
  ticker: string
  stock_name: string
  sector: string
  type: 'achat' | 'vente'
  price_min: string
  price_max: string
  horizon: 'court' | 'long'
  gain_potential: string
  objectif_1: string
  objectif_2: string
  stop_loss: string
  risk_level: 'Faible' | 'Modéré' | 'Élevé'
  content: string
  is_active: boolean
}
const EMPTY: FormState = {
  ticker: '',
  stock_name: '',
  sector: '',
  type: 'achat',
  price_min: '',
  price_max: '',
  horizon: 'court',
  gain_potential: '',
  objectif_1: '',
  objectif_2: '',
  stop_loss: '',
  risk_level: 'Modéré',
  content: '',
  is_active: true,
}

export default function AdminAlerts() {
  const [alerts, setAlerts] = useState<DbAlert[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [form, setForm] = useState<FormState | null>(null)
  const [saving, setSaving] = useState(false)
  const loadedOnce = useRef(false)
  const { tickers } = useBrvmTickers()
  const { history, rsi } = useTickerHistory(form?.ticker || null)

  async function load(silent = false) {
    if (!loadedOnce.current && !silent) setLoading(true)
    try {
      setAlerts(await adminApi.get<DbAlert[]>('/alerts'))
      setError('')
    } catch (err) {
      if (!loadedOnce.current) setError(err instanceof Error ? err.message : 'Erreur de chargement')
    }
    loadedOnce.current = true
    setLoading(false)
  }

  useEffect(() => {
    load()
  }, [])

  function openEdit(a: DbAlert) {
    let message = ''
    let priceMax = ''
    let gain = ''
    if (a.content) {
      try {
        const p = JSON.parse(a.content)
        message = p.message ?? ''
        priceMax = p.price_max != null ? String(p.price_max) : ''
        gain = p.gain_potential ?? ''
      } catch {
        message = a.content
      }
    }
    const extended = a as DbAlert & {
      ticker?: string | null
      sector?: string | null
      objectif_1?: number | null
      objectif_2?: number | null
      stop_loss?: number | null
      risk_level?: string | null
    }
    setForm({
      id: a.id,
      ticker: extended.ticker ?? '',
      stock_name: a.stock_name,
      sector: extended.sector ?? '',
      type: a.type,
      price_min: a.price_target != null ? String(a.price_target) : '',
      price_max: priceMax,
      horizon: a.horizon ?? 'court',
      gain_potential: gain,
      objectif_1: extended.objectif_1 != null ? String(extended.objectif_1) : '',
      objectif_2: extended.objectif_2 != null ? String(extended.objectif_2) : '',
      stop_loss: extended.stop_loss != null ? String(extended.stop_loss) : '',
      risk_level: (extended.risk_level as FormState['risk_level']) ?? 'Modéré',
      content: message,
      is_active: a.is_active,
    })
  }

  function selectTicker(ticker: string) {
    if (!form) return
    const t = tickers.find((x) => x.ticker === ticker)
    setForm({
      ...form,
      ticker,
      stock_name: t?.company_name ? `${ticker} — ${t.company_name}` : ticker,
    })
  }

  async function save() {
    if (!form || !form.stock_name.trim()) return
    setSaving(true)
    const body = {
      stock_name: form.stock_name.trim(),
      ticker: form.ticker || null,
      sector: form.sector || null,
      type: form.type,
      price_min: form.price_min ? Number(form.price_min) : null,
      price_max: form.price_max ? Number(form.price_max) : null,
      horizon: form.horizon,
      gain_potential: form.gain_potential || null,
      objectif_1: form.objectif_1 ? Number(form.objectif_1) : null,
      objectif_2: form.objectif_2 ? Number(form.objectif_2) : null,
      stop_loss: form.stop_loss ? Number(form.stop_loss) : null,
      risk_level: form.risk_level,
      content: form.content || null,
      is_active: form.is_active,
    }
    try {
      if (form.id) await adminApi.patch(`/alerts/${form.id}`, body)
      else await adminApi.post('/alerts', body)
      setForm(null)
      load(true)
    } catch (err) {
      alert(err instanceof Error ? err.message : 'Erreur lors de la sauvegarde')
    }
    setSaving(false)
  }

  async function toggleActive(a: DbAlert) {
    setAlerts((prev) => prev.map((x) => (x.id === a.id ? { ...x, is_active: !x.is_active } : x)))
    try {
      await adminApi.patch(`/alerts/${a.id}`, { is_active: !a.is_active })
      load(true)
    } catch (err) {
      load(true)
      alert(err instanceof Error ? err.message : 'Erreur lors de la mise à jour')
    }
  }

  async function remove(id: string) {
    if (!confirm('Supprimer cette alerte ?')) return
    const previous = alerts
    setAlerts((prev) => prev.filter((x) => x.id !== id))
    try {
      await adminApi.delete(`/alerts/${id}`)
      load(true)
    } catch (err) {
      setAlerts(previous)
      alert(err instanceof Error ? err.message : 'Erreur lors de la suppression')
    }
  }

  return (
    <div>
      <ScreenHeader
        icon={<Bell size={20} color="#F5C842" />}
        title="Alertes Opportunité"
        action={
          <button
            onClick={() => setForm({ ...EMPTY })}
            className="flex items-center justify-center rounded-full"
            style={{ width: 38, height: 38, backgroundColor: '#F5C842' }}
          >
            <Plus size={18} color="#0A0A0F" />
          </button>
        }
      />

      {loading && <p className="text-textSub text-sm">Chargement…</p>}
      {error && !loading && <p className="text-sell text-sm">{error}</p>}
      {!loading && !error && alerts.length === 0 && <EmptyState icon={<Bell size={30} color="#4A4A5A" />} title="Aucune alerte" />}

      {!loading &&
        !error &&
        alerts.map((a) => (
          <div key={a.id} className="rounded-2xl p-3.5 mb-2.5" style={{ backgroundColor: '#111118', border: '1px solid #2A2A3A', opacity: a.is_active ? 1 : 0.55 }}>
            <div className="flex items-center justify-between mb-1">
              <span className="flex items-center gap-2">
                <span
                  className="rounded-md px-2 py-0.5 text-[9px] font-extrabold"
                  style={{ backgroundColor: a.type === 'achat' ? '#052E16' : '#200A0A', color: a.type === 'achat' ? '#22C55E' : '#EF4444' }}
                >
                  {a.type === 'achat' ? 'ACHAT' : 'VENTE'}
                </span>
                <span className="text-white font-bold text-sm">{a.stock_name}</span>
              </span>
              <span className="text-textMuted text-xs">{formatRelativeTime(new Date(a.created_at))}</span>
            </div>
            <div className="flex items-center gap-2 mt-2">
              <ActionBtn icon={Edit3} label="Modifier" color="#F5C842" onClick={() => openEdit(a)} />
              <ActionBtn icon={a.is_active ? EyeOff : Eye} label={a.is_active ? 'Désactiver' : 'Activer'} color="#8A8A9A" onClick={() => toggleActive(a)} />
              <ActionBtn icon={Trash2} label="Supprimer" color="#EF4444" onClick={() => remove(a.id)} />
            </div>
          </div>
        ))}

      {form && (
        <ModalSheet title={form.id ? 'Modifier alerte' : 'Nouvelle alerte'} onClose={() => setForm(null)}>
          <div>
            <FieldLabel required>Valeur BRVM</FieldLabel>
            <select
              value={form.ticker}
              onChange={(e) => selectTicker(e.target.value)}
              className="w-full rounded-xl px-3.5 py-3 text-white text-sm outline-none"
              style={{ backgroundColor: '#111118', border: '1px solid #2A2A3A' }}
            >
              <option value="">— Choisir une valeur —</option>
              {tickers.map((t) => (
                <option key={t.ticker} value={t.ticker}>
                  {t.ticker} {t.company_name ? `— ${t.company_name}` : ''}
                </option>
              ))}
            </select>
            <p className="text-textMuted text-[11px] mt-1.5">
              Le graphique ci-dessous se génère automatiquement à partir de l'historique réel de cette valeur.
            </p>
          </div>

          {form.ticker && (
            <div>
              <FieldLabel>Graphique (automatique)</FieldLabel>
              <StockChart history={history} rsi={rsi} />
            </div>
          )}

          <div>
            <FieldLabel>Secteur</FieldLabel>
            <TextInput value={form.sector} onChange={(v) => setForm({ ...form, sector: v })} placeholder="ex: Bancaire, Télécoms, Agro-industrie" />
          </div>

          <div>
            <FieldLabel>Type</FieldLabel>
            <PillGroup
              value={form.type}
              onChange={(v) => setForm({ ...form, type: v })}
              options={[
                { value: 'achat', label: 'ACHAT' },
                { value: 'vente', label: 'VENTE' },
              ]}
              colors={{ achat: '#22C55E', vente: '#EF4444' }}
            />
          </div>

          <div>
            <FieldLabel>Niveau de risque</FieldLabel>
            <PillGroup
              value={form.risk_level}
              onChange={(v) => setForm({ ...form, risk_level: v })}
              options={[
                { value: 'Faible', label: 'FAIBLE' },
                { value: 'Modéré', label: 'MODÉRÉ' },
                { value: 'Élevé', label: 'ÉLEVÉ' },
              ]}
              colors={{ Faible: '#22C55E', 'Modéré': '#F5C842', 'Élevé': '#EF4444' }}
            />
          </div>

          <div>
            <FieldLabel>Cours limite (prix d'entrée)</FieldLabel>
            <div className="flex items-center gap-3">
              <TextInput type="number" value={form.price_min} onChange={(v) => setForm({ ...form, price_min: v })} placeholder="ex: 10800" />
              <div className="flex items-center justify-center rounded-xl px-4 py-3 text-textSub text-xs font-semibold flex-shrink-0" style={{ backgroundColor: '#111118', border: '1px solid #2A2A3A' }}>
                FCFA
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <FieldLabel>Objectif 1</FieldLabel>
              <TextInput type="number" value={form.objectif_1} onChange={(v) => setForm({ ...form, objectif_1: v })} placeholder="ex: 12500" />
            </div>
            <div>
              <FieldLabel>Objectif 2</FieldLabel>
              <TextInput type="number" value={form.objectif_2} onChange={(v) => setForm({ ...form, objectif_2: v })} placeholder="ex: 14000" />
            </div>
          </div>

          <div>
            <FieldLabel>Stop loss</FieldLabel>
            <TextInput type="number" value={form.stop_loss} onChange={(v) => setForm({ ...form, stop_loss: v })} placeholder="ex: 9200" />
          </div>

          <div>
            <FieldLabel>Horizon</FieldLabel>
            <PillGroup
              value={form.horizon}
              onChange={(v) => setForm({ ...form, horizon: v })}
              options={[
                { value: 'court', label: 'COURT TERME' },
                { value: 'long', label: 'LONG TERME' },
              ]}
              colors={{ court: '#F97316', long: '#8A8A9A' }}
            />
          </div>

          <div>
            <FieldLabel>Potentiel de gain moyen</FieldLabel>
            <div className="flex items-center gap-3">
              <div className="flex-1">
                <TextInput type="number" value={form.gain_potential} onChange={(v) => setForm({ ...form, gain_potential: v })} placeholder="ex: 30" />
              </div>
              <div className="flex items-center justify-center rounded-xl px-4 py-3 text-primary font-bold" style={{ backgroundColor: '#111118', border: '1px solid #2A2A3A' }}>
                %
              </div>
            </div>
          </div>

          <div>
            <FieldLabel>Analyse</FieldLabel>
            <TextArea value={form.content} onChange={(v) => setForm({ ...form, content: v })} placeholder="Ex: BOA CI évolue dans une tendance haussière à moyen terme..." />
          </div>

          <div className="flex items-center justify-between">
            <span className="text-white font-semibold text-sm">Active</span>
            <Toggle checked={form.is_active} onChange={(v) => setForm({ ...form, is_active: v })} />
          </div>

          <button
            onClick={save}
            disabled={saving || !form.stock_name.trim()}
            className="w-full py-3.5 rounded-xl font-extrabold text-sm disabled:opacity-40"
            style={{ backgroundColor: '#F5C842', color: '#0A0A0F' }}
          >
            {saving ? 'Enregistrement…' : 'Enregistrer'}
          </button>
        </ModalSheet>
      )}
    </div>
  )
}

function ActionBtn({ icon: Icon, label, color, onClick }: { icon: typeof Edit3; label: string; color: string; onClick: () => void }) {
  return (
    <button onClick={onClick} className="flex items-center gap-1.5 rounded-lg px-2 py-1 text-[10px] font-bold" style={{ backgroundColor: '#1A1A24', color }}>
      <Icon size={12} /> {label}
    </button>
  )
}
