import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'

export interface BrvmTicker {
  ticker: string
  company_name: string | null
  cours: number | null
}

export function useBrvmTickers() {
  const [tickers, setTickers] = useState<BrvmTicker[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let cancelled = false
    supabase
      .from('brvm_cours')
      .select('ticker, company_name, cours')
      .order('ticker', { ascending: true })
      .then(({ data }) => {
        if (!cancelled) {
          setTickers((data ?? []) as BrvmTicker[])
          setLoading(false)
        }
      })
    return () => {
      cancelled = true
    }
  }, [])

  return { tickers, loading }
}

export interface HistoryPoint {
  day: string
  cours: number
}

// RSI(14) — calculé uniquement à partir des cours de clôture réels, comme
// c'est l'usage standard (pas besoin d'open/high/low pour le RSI).
function computeRSI(closes: number[], period = 14): (number | null)[] {
  const rsi: (number | null)[] = new Array(closes.length).fill(null)
  if (closes.length < period + 1) return rsi

  let gains = 0
  let losses = 0
  for (let i = 1; i <= period; i++) {
    const diff = closes[i] - closes[i - 1]
    if (diff > 0) gains += diff
    else losses -= diff
  }
  let avgGain = gains / period
  let avgLoss = losses / period
  rsi[period] = avgLoss === 0 ? 100 : 100 - 100 / (1 + avgGain / avgLoss)

  for (let i = period + 1; i < closes.length; i++) {
    const diff = closes[i] - closes[i - 1]
    const gain = diff > 0 ? diff : 0
    const loss = diff < 0 ? -diff : 0
    avgGain = (avgGain * (period - 1) + gain) / period
    avgLoss = (avgLoss * (period - 1) + loss) / period
    rsi[i] = avgLoss === 0 ? 100 : 100 - 100 / (1 + avgGain / avgLoss)
  }
  return rsi
}

export function useTickerHistory(ticker: string | null) {
  const [history, setHistory] = useState<HistoryPoint[]>([])
  const [rsi, setRsi] = useState<(number | null)[]>([])
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (!ticker) {
      setHistory([])
      setRsi([])
      return
    }
    let cancelled = false
    setLoading(true)
    supabase
      .from('brvm_history')
      .select('day, cours')
      .eq('ticker', ticker)
      .order('day', { ascending: true })
      .then(({ data }) => {
        if (cancelled) return
        const points = ((data ?? []) as HistoryPoint[]).filter((p) => p.cours != null)
        setHistory(points)
        setRsi(computeRSI(points.map((p) => Number(p.cours))))
        setLoading(false)
      })
    return () => {
      cancelled = true
    }
  }, [ticker])

  return { history, rsi, loading }
}
