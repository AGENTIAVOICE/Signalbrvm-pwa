import { useCallback, useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'

// Clé publique VAPID — sans risque à exposer côté client (c'est fait pour).
const VAPID_PUBLIC_KEY = 'BOe1I375DqzzBUQIvYOgs4eaBIC6UwuGdHVWZa336qmaYKwT9-0PhxMn-_bhZ7iJuk4Psqn_Ju3M4bDYrQ6rlXU'

function urlBase64ToUint8Array(base64String: string): Uint8Array {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4)
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/')
  const rawData = window.atob(base64)
  return Uint8Array.from([...rawData].map((c) => c.charCodeAt(0)))
}

function bufferToBase64(buffer: ArrayBuffer | null): string {
  if (!buffer) return ''
  const bytes = new Uint8Array(buffer)
  let binary = ''
  for (const b of bytes) binary += String.fromCharCode(b)
  return window.btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '')
}

// Extrait endpoint + clés de façon robuste — Safari/iOS a un support
// historiquement peu fiable de PushSubscription.toJSON(), donc on lit les
// clés directement via getKey() plutôt que de faire confiance à toJSON().
function extractSubscriptionData(sub: PushSubscription): { endpoint: string; p256dh: string; auth: string } | null {
  const endpoint = sub.endpoint
  const p256dh = bufferToBase64(sub.getKey('p256dh'))
  const auth = bufferToBase64(sub.getKey('auth'))
  if (!endpoint || !p256dh || !auth) return null
  return { endpoint, p256dh, auth }
}

// Enregistre (ou met à jour) l'abonnement en base — appelé à la fois quand on
// crée un nouvel abonnement ET quand on retrouve un abonnement déjà existant
// côté navigateur, pour "auto-réparer" un abonnement jamais sauvegardé lors
// d'un essai précédent (ex: session expirée à ce moment-là).
async function persistSubscription(sub: PushSubscription): Promise<{ ok: true } | { ok: false; error: string }> {
  const extracted = extractSubscriptionData(sub)
  if (!extracted) return { ok: false, error: "Abonnement push incomplet (clés manquantes) — réessaie." }

  const { data, error: sessionErr } = await supabase.auth.getSession()
  if (sessionErr) return { ok: false, error: sessionErr.message }
  const userId = data.session?.user.id
  if (!userId) return { ok: false, error: 'Session utilisateur introuvable — reconnecte-toi puis réessaie.' }

  const { error: dbErr } = await supabase.from('push_subscriptions').upsert(
    { user_id: userId, endpoint: extracted.endpoint, p256dh: extracted.p256dh, auth: extracted.auth },
    { onConflict: 'endpoint' }
  )
  if (dbErr) return { ok: false, error: dbErr.message }
  return { ok: true }
}

export function usePushSubscription() {
  const [supported, setSupported] = useState(false)
  const [subscribed, setSubscribed] = useState(false)
  const [loading, setLoading] = useState(false)
  const [lastError, setLastError] = useState<string | null>(null)
  const [needsHomeScreenInstall, setNeedsHomeScreenInstall] = useState(false)

  useEffect(() => {
    const isSupported = 'serviceWorker' in navigator && 'PushManager' in window
    setSupported(isSupported)

    const isIOS = /iPhone|iPad|iPod/i.test(navigator.userAgent)
    const isStandalone =
      window.matchMedia('(display-mode: standalone)').matches ||
      (navigator as unknown as { standalone?: boolean }).standalone === true
    // Sur iOS, Safari ne permet les notifications push que si la PWA a été
    // ajoutée à l'écran d'accueil (sinon PushManager.subscribe() échoue).
    setNeedsHomeScreenInstall(isIOS && !isStandalone)

    if (!isSupported) return
    navigator.serviceWorker.ready.then(async (reg) => {
      const sub = await reg.pushManager.getSubscription()
      if (sub) {
        // Abonnement déjà présent côté navigateur : on (re)vérifie qu'il est
        // bien enregistré en base plutôt que de faire confiance à sa seule
        // existence — c'est justement ce contrôle qui manquait avant.
        const result = await persistSubscription(sub)
        setSubscribed(result.ok)
        if (!result.ok) setLastError(result.error)
      } else {
        setSubscribed(false)
      }
    })
  }, [])

  const subscribe = useCallback(async () => {
    if (!supported) {
      setLastError('Ce navigateur ne supporte pas les notifications push.')
      return false
    }
    setLoading(true)
    setLastError(null)
    try {
      const permission = await Notification.requestPermission()
      if (permission !== 'granted') {
        setLastError(
          permission === 'denied'
            ? "Autorisation refusée. Réactive-la dans les réglages du navigateur pour ce site, puis réessaie."
            : 'Autorisation non accordée.'
        )
        setLoading(false)
        return false
      }
      const reg = await navigator.serviceWorker.ready
      let sub = await reg.pushManager.getSubscription()
      if (!sub) {
        sub = await reg.pushManager.subscribe({
          userVisibleOnly: true,
          applicationServerKey: urlBase64ToUint8Array(VAPID_PUBLIC_KEY) as BufferSource,
        })
      }
      const result = await persistSubscription(sub)
      if (!result.ok) {
        setLastError(result.error)
        setLoading(false)
        return false
      }
      setSubscribed(true)
      setLoading(false)
      return true
    } catch (err) {
      console.error('Erreur abonnement push:', err)
      setLastError(err instanceof Error ? err.message : String(err))
      setLoading(false)
      return false
    }
  }, [supported])

  const unsubscribe = useCallback(async () => {
    if (!supported) return
    setLoading(true)
    try {
      const reg = await navigator.serviceWorker.ready
      const sub = await reg.pushManager.getSubscription()
      if (sub) {
        await supabase.from('push_subscriptions').delete().eq('endpoint', sub.endpoint)
        await sub.unsubscribe()
      }
      setSubscribed(false)
    } catch (err) {
      console.error('Erreur désabonnement push:', err)
    }
    setLoading(false)
  }, [supported])

  return { supported, subscribed, loading, lastError, needsHomeScreenInstall, subscribe, unsubscribe }
}
